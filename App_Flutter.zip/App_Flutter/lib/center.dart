import 'package:flutter/material.dart';
import 'package:meuapp/center.dart';

class CenterLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: FlutterLogo(size: 64.0));
  }
}